<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Tugas</title>
</head>

<body style="text-align:center;">
    <h1><?= $msg1; ?></h1>
    <h2><?= $msg2; ?></h2>
</body>

</html>